<?php

namespace SmartCore\Module\Example;

use SmartCore\Bundle\CMSBundle\Module\Bundle;

class ExampleModule extends Bundle
{
    public function hasAdmin()
    {
        return false;
    }
}
