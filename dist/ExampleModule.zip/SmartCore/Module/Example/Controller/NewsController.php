<?php

namespace SmartCore\Module\Example\Controller;

use SmartCore\Bundle\CMSBundle\Response;
use SmartCore\Bundle\CMSBundle\Module\Controller;

class ExampleController extends Controller
{
    protected function init()
    {
        $this->View->setEngine('twig');
    }

    public function indexAction($pageNum = 1)
    {
        $em = $this->get('doctrine.orm.default_entity_manager');

        $this->View->items = $em->getRepository('ExampleModule:Example')->findAll();

        $response = new Response($this->View);
        // @todo EIP.
        return $response;
    }
}
